/*1. Дан объект

 const car = {
     model: 'tesla',
     adress: {
         country: {
             city: {
                 name: 'Boston',
                 street: {
                     name: 'pushkina',
                     number: 2
                 }
             }
         },
         region: ['Iowa','Texas','California']
     },
     specs: {
         price: {
             low: 2000,
             mid: 3000,
             high: 5000
         },
         engine: {
             power: 400,
             lowPower: 100
         }
     }
 };

С помощью деструктуризации запишите в отдельны переменные: 

//1.1 Название города в котором находится авто 
const { adress: { country: { city: { name: cityName } } } } = car;
console.log(cityName);



//1.2 Четвертый регион из поля region (по умолчанию значение должно быть 'Arizona') 
const { adress:{region:[,,,fourth = 'Arizona']}} = car;
console.log(fourth);



//1.3 Поле high, объекта price 
const { specs: { price: {high}}} = car;
console.log(high);



//1.4 Из объекта specs записать поле fuelConsumption, которое по умолчанию должно являться объектом вида: { city: 12, mix: 10, country: 8 }
const { specs: {fuelConsumption = {city: 12,mix: 10, country: 8} }} = car;
console.log(fuelConsumption);
*/




//2. Даны 2 массива:
let people1 = ['Samuel', 'Jack', 'Thomas','Henry','Leo','Connor','David','Ryan'];
let people2 = ['Connor','Stanley','Leo', 'Albert','Owen','Oliver','Ethan','Thomas'];



//2.1 Пользователь вводит имя, если это имя есть в массиве people1, добавьте это имя в конец people2. 
/*
const userName = prompt(`enter name`);
for(let i = 0;i < people1.length;i++){
    if (userName === people1[i]) {
        people2.push(userName);
        console.log(people1);
        console.log(people2);
        break;
    }else{
        continue;
    }
}
*/



//2.2 Пользователь вводит имя, если это имя есть в массиве people2, удалите это имя из массива.
/*
const userNamePeople2Delete = prompt(`enter name`);
for(let i = 0;i<people2.length;i++){
    if(userNamePeople2Delete === people2[i]){
        delete(people2[i]);
        console.log(people2);
        break;
    }else{
        continue;
    }
}
*/



//2.3 Создайте массив только из тех имен, которые совпадают в обоих массивах.
/*
const newMassive = [];
for(let i = 0; i<people1.length; i++){
    if(people1[i] === people2[0] || people1[i] === people2[1] || people1[i] === people2[2] || people1[i] === people2[3] || people1[i] === people2[4] || people1[i] === people2[5] || people1[i] === people2[6] || people1[i] === people2[7]){
        newMassive.push(people1[i]);
    }else{
        continue;
    }
}
console.log(newMassive);
*/



//2.4 Объедините массивы people1 и people2 так, чтобы в получившемся массиве не было одинаковых имен.
/*
const people = people1.slice();
for(let name of people2){
    if(!people.includes(name)){
        people.push(name);
    }
}
console.log(people);
*/
//тут я сначала использовала for...in но это на работает, я поискала в интернете и нашла for..of, получается первый получает индекс, а второй значения
//можно было создать переменную и там получать значения благодаря нахождению индекса:
//for(let name in people2){
//    let pName = people[name];      
//    if(!people.includes(pName)){
//        people.push(pName);
//    }
//} 


//3.
//Напишите функцию hyphenDestroyer(), которая преобразует
//строки вида «my-short-string» в «my short string».
//То есть, дефисы удаляются и вместо них появляются пробелы.
//Например:
//hyphenDestroyer ("background-color") === 'background сolor';
//hyphenDestroyer ("list-style-image") === 'list style image';
//hyphenDestroyer ("-webkit-transition") === 'webkit transition';
/*
let str1 = "background-color";
let str2 = "list-style-image";
let str3 = "-webkit-transition";

function hyphenDestroyer(string) {
    let result = string.replace(/-/g,' ');
    return result;
}
console.log(hyphenDestroyer(str3));
*/



//4. Дан массив сonst arr = [2,5,7,12,62,23,88,153];
//выведите в консоль наибольшее ЧЕТНОЕ число из этого массива
/*
const arr = [2,5,7,12,62,23,88,153];
let max2Num = 0;
for(let i = 0;i<arr.length;i++){
    if(arr[i]%2 == 0){
        if(arr[i] > max2Num){
            max2Num = arr[i];
        }else{
            continue;
        }
    }else{
        continue;
    }
}
console.log(max2Num);
*/



//5. Валерчик и Олежик очень любят поиграть в контр страйк,
//Даны два объекта, в которых записано сколько раз побеждал каждый из них
//const valerchik = {
//    wins: 213,
//    loses: 123
//};

//const olejik = {
//    wins: 51,
//    loses: 64
//};

//cоздать функцию getPercentage() которая принимает любой объект из выше перечисленных и возвращает строку с процентом побед и поражений в  виде 
//'процент побед 45%, процент поражений 55%'
/*
const valerchik = {
    wins: 213,
    loses: 123
};

const olejik = {
    wins: 51,
    loses: 64
};

function getPercentage(obj){
    let all = obj.wins + obj.loses;
    let win = Math.round((obj.wins / all) * 100);
    let lose = Math.round((obj.loses / all) * 100);
    return `процент побед ${win}%, процент поражений ${lose}%`;
    
}

console.log(getPercentage(valerchik));
*/



//6.Написать функцию которая возвращает годовую оценку по любому предмету (функция должна принимать 4 числа)
/*
function yearGrade(firstgrade,secondgrade,thirdGrade,fourthGrade){
    let sumOfGrades = firstgrade + secondgrade + thirdGrade + fourthGrade;
    let studentYearGrade = sumOfGrades / 4;
    return studentYearGrade;
}
console.log(yearGrade(12,3,8,5));
*/



//7. Написать функцию, которая принимает случайный
//двумерный массив (разной длины). Функция
//возвращает тот массив сумма элементов которого
//наибольшая.
const arr1 = [[12,31,3,0], [456,4242,732]];
const arr2 = [[2,54,756,90], [123,3,4,546,393]];

function getMassivMassiv(array1,array2){
    let sum1 = 0;
    let sum2 = 0;
    for(let j = 0; j<array1.length; j++){
        for(let i = 0; i<array1[j].length; i++){
            sum1 += array1[j][i];
        }
    }
    for(let j = 0; j<array2.length; j++){
        for(let i = 0; i<array2[j].length; i++){
            sum2 += array2[j][i];
        }
    }
    let result ;
    if(sum1 > sum2){
        result = 'array1';
    }else{
        result = 'array2';
    }

    return `массив ${result} больше `;
}
console.log(getMassivMassiv(arr1,arr2));
